let fname=document.getElementById('fname').value;
console.log(fname);
 
let uname=document.getElementById('uname').value;
console.log(uname);

let email=document.getElementById('email').value;
console.log(email);
